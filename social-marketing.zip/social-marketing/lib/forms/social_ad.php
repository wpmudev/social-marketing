<?php
/* Deprecated */